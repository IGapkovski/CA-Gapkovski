$(document).ready(function () {
    console.log("AddOrUpdateCategory");
});