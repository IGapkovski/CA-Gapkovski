$(document).ready(function () {
    console.log("categories");
});