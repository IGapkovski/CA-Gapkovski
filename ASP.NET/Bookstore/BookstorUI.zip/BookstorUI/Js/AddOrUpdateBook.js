$(document).ready(function () {
   let url = window.location.href;
   let bookID = url.substring(url.indexOf("?") + 1);

   GetAllCategories.then((result) => {
      result.forEach((category) => {
         $("#inputCategory").append(
            `<option id="${category.categoryID}">${category.categoryName}</option>`
         );
      });
   }).catch((err) => {
      console.log("AddOrUpdateBooks/GetAllCategories", err);
   });

   GetBook(bookID)
      .then((result) => {
         console.log(formatDate(new Date(result.issueDate)));
         $("#inputTitle").val(result.title);
         $("#inputAuthor").val(result.author);
         $("#inputDescription").val(result.description);
         $("#inputIssueDate").val(formatDate(result.issueDate));
         $("#inputPrice").val(result.price);
      })
      .catch((err) => {
         console.log("AddOrUpdateBooks/GetBook", err);
      });

   $("#Save").click(() => {
      let book = {
        title: $("#inputTitle").val(),
        author: $("#inputAuthor").val(),
        description: $("#inputDescription").val(),
        categoryName: $("#inputCategory").find(":selected").val(),
        issueDate: $("#inputIssueDate").val()
      };
      console.log(book);
   });
});
