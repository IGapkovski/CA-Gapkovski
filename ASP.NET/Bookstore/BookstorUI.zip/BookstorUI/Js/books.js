$(document).ready(function () {
    GetAllCategories
      .then((result) => {
         result.forEach((category) => {
            $("#allbooks").append(
               `<div class="books-category container-fluid">
                <h3>${category.categoryName}</h3>
                <hr>
                <br>
                <div class="book-container" id="${category.categoryName}">
                  
                </div>
                </div>`
            );

            GetBooksByCategoryID(category.categoryID)
               .then((result) => {
                  insertCards(result, `#${category.categoryName}`);
               })
               .catch((err) => {
                  console.log("books.html", err);
               });
         });
      })
      .catch((err) => {
         console.log("books.html/getAllCategories", err);
      });
});
