﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using EmployeeManager.MVC.Models;

namespace EmployeeManager.MVC.Controllers
{
    public class EmployeeManagerController : Controller
    {
        private AppDbContext db = null;

        public EmployeeManagerController(AppDbContext db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            List<Employee> model =
                 (from e in db.Employess
                  orderby e.EmployeeID
                  select e).ToList();

            return View(model);
        }

        public IActionResult Insert()
        {
            FillCountries();
            return View();

        }

        [HttpPost]
        public IActionResult Insert(Employee model)
        {
            FillCountries();
            if (ModelState.IsValid)
            {
                db.Employess.Add(model);
                db.SaveChanges();
                ViewBag.Messaage = "Employee inserted";
            }
            return View(model);
        }

        public IActionResult Update(int id)
        {
            FillCountries();
            Employee model = db.Employess.Find(id);
            return View(model);
        }

        [HttpPost]
        public IActionResult Update(Employee model)
        {
            FillCountries();
            if (ModelState.IsValid)
            {
                db.Employess.Update(model);
                db.SaveChanges();
                ViewBag.Messaage = "Employee updated";
            }
            return View(model);
        }

        [ActionName("Delete")]
        public IActionResult ConfirmDelete(int id)
        {
            Employee model = db.Employess.Find(id);
            return View(model);
        }
        public IActionResult Delete(int employeeID)
        {
            Employee model = db.Employess.Find(employeeID);
            db.Employess.Remove(model);
            db.SaveChanges();
            TempData["Message"] = "Deleted";
            return RedirectToAction();
        }

        private void FillCountries()
        {
            List<SelectListItem> countries =
                (from c in db.Countries
                 orderby c.Name ascending
                 select new SelectListItem()
                 {
                     Text = c.Name,
                     Value = c.Name
                 }).ToList();

            ViewBag.Countries = countries;
        }
    }
}
