﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeManager.MVC.Models
{
    [Table("Employees")]
    public class Employee
    {
        [Column("EmployeeID")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required(ErrorMessage = "Employee ID is required")]
        [Display(Name = "Employee ID")]
        public int EmployeeID { get; set; }

        [Column("FirstName")]
        [Required(ErrorMessage = "FirstName is required")]
        [Display(Name = "First Name")]
        [StringLength(10, ErrorMessage = "Must be lesst then 10")]
        public String FirstName { get; set; }

        [Column("LastName")]
        [Required(ErrorMessage = "LastName is required")]
        [Display(Name = "Last Name")]
        [StringLength(20, ErrorMessage = "Must be lesst then 20")]
        public String LastName { get; set; }

        [Column("Title")]
        [Required(ErrorMessage = "Title is required")]
        [Display(Name = "Title")]
        [StringLength(30, ErrorMessage = "Must be lesst then 30")]
        public String Title { get; set; }

        [Column("BirthDate")]
        [Required(ErrorMessage = "Birth Date is required")]
        [Display(Name = "Birth Date")]
        public DateTime BirthDate { get; set; }

        [Column("HireDate")]
        [Required(ErrorMessage = "Hire Date is required")]
        [Display(Name = "Hire Date")]
        public DateTime HireDate { get; set; }

        [Column("Country")]
        [Required(ErrorMessage = "Country is required")]
        [Display(Name = "Country")]
        [StringLength(15, ErrorMessage = "Must be lesst then 15")]
        public String Country { get; set; }

        [Column("Notes")]
        [Display(Name = "Notes")]
        [StringLength(500, ErrorMessage = "Must be lesst then 500")]
        public String Notes { get; set; }
    }
}
